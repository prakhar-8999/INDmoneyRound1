export const LogoImageUrl =
  "https://indcdn.indmoney.com/cdn-cgi/image/quality=auto,format=auto,width=150/https://indcdn.indmoney.com/public/ind-marketing/indmoney-weblogo.png";
